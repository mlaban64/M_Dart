GNATdoc.InheritanceIndex = [
  {
    "label": "Camera",
    "docHref": "docs/cameras.html#L16C9",
    "inherited": [
      {
        "label": "Pinhole_Camera",
        "docHref": "docs/cameras.pinhole_cameras.html#L10C9"
      }
    ]
  },
  {
    "label": "Filter",
    "docHref": "docs/cameras.html#L124C9",
    "inherited": [
      {
        "label": "Box_Filter",
        "docHref": "docs/cameras.html#L130C9"
      },
      {
        "label": "MultiStage_Filter",
        "docHref": "docs/cameras.html#L133C9"
      },
      {
        "label": "Poisson_Filter",
        "docHref": "docs/cameras.html#L136C9"
      }
    ]
  },
  {
    "label": "Light",
    "docHref": "docs/lights.html#L19C9",
    "inherited": [
      {
        "label": "Ambient_Light",
        "docHref": "docs/lights.ambient.html#L13C9"
      },
      {
        "label": "Directional_Light",
        "docHref": "docs/lights.directionals.html#L11C9"
      },
      {
        "label": "Point_Light",
        "docHref": "docs/lights.points.html#L11C9"
      }
    ]
  },
  {
    "label": "Material",
    "docHref": "docs/materials.html#L16C9",
    "inherited": [
      {
        "label": "Lambertian",
        "docHref": "docs/materials.lambertians.html#L9C9"
      },
      {
        "label": "Reflective",
        "docHref": "docs/materials.reflective.html#L12C9"
      }
    ]
  },
  {
    "label": "Object",
    "docHref": "docs/objects.html#L23C9",
    "inherited": [
      {
        "label": "Unit_Cone",
        "docHref": "docs/objects.unit_cones.html#L13C9"
      },
      {
        "label": "Unit_Cube",
        "docHref": "docs/objects.unit_cubes.html#L13C9"
      },
      {
        "label": "Unit_Cylinder",
        "docHref": "docs/objects.unit_cylinders.html#L13C9"
      },
      {
        "label": "Unit_Sphere",
        "docHref": "docs/objects.unit_spheres.html#L13C9"
      }
    ]
  },
  {
    "label": "Sampler",
    "docHref": "docs/samplers.html#L18C9",
    "inherited": [
      {
        "label": "Sampler_2D",
        "docHref": "docs/samplers.html#L83C9"
      },
      {
        "label": "Sampler_3D",
        "docHref": "docs/samplers.html#L88C9"
      },
      {
        "label": "UnitSquare_Random_Sampler",
        "docHref": "docs/samplers.unitsquares.html#L18C9"
      },
      {
        "label": "UnitSquare_Regular_Sampler",
        "docHref": "docs/samplers.unitsquares.html#L15C9"
      }
    ]
  }
];