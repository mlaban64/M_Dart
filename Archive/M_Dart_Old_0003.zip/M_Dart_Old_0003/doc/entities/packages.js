GNATdoc.EntitiesCategory = {
  "label": "Packages",
  "entities": [
    {
      "label": "GNATtest_Standard",
      "docHref": "docs/gnattest_generated.gnattest_standard.html#L2C12",
      "declared": "Gnattest_Generated",
      "srcHref": "srcs/gnattest_generated.ads.html#L2"
    }
  ]
};