#ifndef GFXLIB_H
#define GFXLIB_H

/* Opens the window */
void GfxLib_OpenWindow (int width, int height, char *title);

/* Clse the window */
void gfxlib_closewindow ();

/* Set a pixel at (x,y) */
void gfxlib_setpixel (int x, int y);

/* Change the current drawing color. */
void gfxlib_setcolor (int red, int green, int blue);

/* Clear the graphics window to the background color. */
void gfxlib_clearwindow ();

/* Change the current background color. */
void gfxlib_setclearwindow_color (int red, int green, int blue);

/* Wait for the user to press a key or mouse button. */
char gfxlib_waitforevent ();

/* Check to see if an event is waiting. */
int gfxlib_checkevent_waiting ();

/* Flush all previous output to the window. */
void gfxlib_flushwindow ();

#endif
