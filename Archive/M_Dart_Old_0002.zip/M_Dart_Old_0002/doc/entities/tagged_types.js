GNATdoc.EntitiesCategory = {
  "label": "Tagged Types",
  "entities": [
    {
      "label": "Camera",
      "docHref": "docs/cameras.html#L13C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L13"
    },
    {
      "label": "Directional_Light",
      "docHref": "docs/lights.directionals.html#L11C9",
      "declared": "Lights.Directionals",
      "srcHref": "srcs/lights-directionals.ads.html#L11"
    },
    {
      "label": "Lambertian",
      "docHref": "docs/materials.lambertians.html#L10C9",
      "declared": "Materials.Lambertians",
      "srcHref": "srcs/materials-lambertians.ads.html#L10"
    },
    {
      "label": "Light",
      "docHref": "docs/lights.html#L17C9",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L17"
    },
    {
      "label": "Material",
      "docHref": "docs/materials.html#L16C9",
      "declared": "Materials",
      "srcHref": "srcs/materials.ads.html#L16"
    },
    {
      "label": "Object",
      "docHref": "docs/objects.html#L23C9",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L23"
    },
    {
      "label": "Sampler",
      "docHref": "docs/samplers.html#L15C9",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L15"
    },
    {
      "label": "Unit_Cone",
      "docHref": "docs/objects.unit_cones.html#L13C9",
      "declared": "Objects.Unit_Cones",
      "srcHref": "srcs/objects-unit_cones.ads.html#L13"
    },
    {
      "label": "Unit_Cube",
      "docHref": "docs/objects.unit_cubes.html#L13C9",
      "declared": "Objects.Unit_Cubes",
      "srcHref": "srcs/objects-unit_cubes.ads.html#L13"
    },
    {
      "label": "Unit_Cylinder",
      "docHref": "docs/objects.unit_cylinders.html#L13C9",
      "declared": "Objects.Unit_Cylinders",
      "srcHref": "srcs/objects-unit_cylinders.ads.html#L13"
    },
    {
      "label": "Unit_Sphere",
      "docHref": "docs/objects.unit_spheres.html#L13C9",
      "declared": "Objects.Unit_Spheres",
      "srcHref": "srcs/objects-unit_spheres.ads.html#L13"
    },
    {
      "label": "UnitSquare_Sampler",
      "docHref": "docs/samplers.unitsquares.html#L12C9",
      "declared": "Samplers.UnitSquares",
      "srcHref": "srcs/samplers-unitsquares.ads.html#L12"
    }
  ]
};