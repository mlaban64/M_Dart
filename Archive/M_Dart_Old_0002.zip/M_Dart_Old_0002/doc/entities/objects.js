GNATdoc.EntitiesCategory = {
  "label": "Constants & Variables",
  "entities": [
    {
      "label": "BLACK_RGB_Spec",
      "docHref": "docs/colors.html#L97C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L97"
    },
    {
      "label": "BLUE_RGB_Spec",
      "docHref": "docs/colors.html#L101C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L101"
    },
    {
      "label": "CYAN_RGB_Spec",
      "docHref": "docs/colors.html#L104C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L104"
    },
    {
      "label": "Default_Assert_Value",
      "docHref": "docs/gnattest_generated.html#L3C4",
      "declared": "Gnattest_Generated",
      "srcHref": "srcs/gnattest_generated.ads.html#L3"
    },
    {
      "label": "Gfx_Main_Image",
      "docHref": "docs/graphix.html#L20C4",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L20"
    },
    {
      "label": "GREEN_RGB_Spec",
      "docHref": "docs/colors.html#L100C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L100"
    },
    {
      "label": "Hp_Stack",
      "docHref": "docs/hitpoints.html#L103C4",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L103"
    },
    {
      "label": "M_Dart_Version",
      "docHref": "docs/utilities.html#L6C4",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L6"
    },
    {
      "label": "MAX_HP_STACK",
      "docHref": "docs/hitpoints.html#L92C4",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L92"
    },
    {
      "label": "MAX_NO_OF_SAMPLES",
      "docHref": "docs/samplers.html#L47C4",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L47"
    },
    {
      "label": "MAX_RECURSION_LEVEL",
      "docHref": "docs/scenes.html#L90C4",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L90"
    },
    {
      "label": "MAX_SPECTRUM",
      "docHref": "docs/colors.html#L108C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L108"
    },
    {
      "label": "ORIGIN_3D",
      "docHref": "docs/linear_math.html#L522C4",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L522"
    },
    {
      "label": "PURPLE_RGB_Spec",
      "docHref": "docs/colors.html#L103C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L103"
    },
    {
      "label": "Ray_2PI",
      "docHref": "docs/core_types.html#L75C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L75"
    },
    {
      "label": "Ray_2PI_Inv",
      "docHref": "docs/core_types.html#L77C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L77"
    },
    {
      "label": "Ray_PI",
      "docHref": "docs/core_types.html#L74C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L74"
    },
    {
      "label": "Ray_PI_div2",
      "docHref": "docs/core_types.html#L78C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L78"
    },
    {
      "label": "Ray_PI_div3",
      "docHref": "docs/core_types.html#L79C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L79"
    },
    {
      "label": "Ray_PI_div4",
      "docHref": "docs/core_types.html#L80C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L80"
    },
    {
      "label": "Ray_PI_Inv",
      "docHref": "docs/core_types.html#L76C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L76"
    },
    {
      "label": "RED_RGB_Spec",
      "docHref": "docs/colors.html#L99C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L99"
    },
    {
      "label": "The_World",
      "docHref": "docs/scenes.html#L113C4",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L113"
    },
    {
      "label": "WHITE_RGB_Spec",
      "docHref": "docs/colors.html#L98C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L98"
    },
    {
      "label": "X_AXIS_3D",
      "docHref": "docs/linear_math.html#L519C4",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L519"
    },
    {
      "label": "Y_AXIS_3D",
      "docHref": "docs/linear_math.html#L520C4",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L520"
    },
    {
      "label": "YELLOW_RGB_Spec",
      "docHref": "docs/colors.html#L102C4",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L102"
    },
    {
      "label": "Z_AXIS_3D",
      "docHref": "docs/linear_math.html#L521C4",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L521"
    }
  ]
};