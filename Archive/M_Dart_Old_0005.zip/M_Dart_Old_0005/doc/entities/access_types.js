GNATdoc.EntitiesCategory = {
  "label": "Access Types",
  "entities": [
    {
      "label": "Camera_Ptr",
      "docHref": "docs/cameras.html#L16C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L16"
    },
    {
      "label": "Light_List_Element_Ptr",
      "docHref": "docs/lights.html#L29C9",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L29"
    },
    {
      "label": "Light_Ptr",
      "docHref": "docs/lights.html#L20C9",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L20"
    },
    {
      "label": "Material_Ptr",
      "docHref": "docs/materials.html#L19C9",
      "declared": "Materials",
      "srcHref": "srcs/materials.ads.html#L19"
    },
    {
      "label": "Object_List_Element_Ptr",
      "docHref": "docs/objects.html#L29C9",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L29"
    },
    {
      "label": "Object_Ptr",
      "docHref": "docs/objects.html#L26C9",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L26"
    },
    {
      "label": "Sampler_Ptr",
      "docHref": "docs/samplers.html#L18C9",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L18"
    },
    {
      "label": "ShadePoint_List_Element_Ptr",
      "docHref": "docs/shadepoints.html#L32C9",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L32"
    },
    {
      "label": "ShadePoint_Ptr",
      "docHref": "docs/shadepoints.html#L29C9",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L29"
    }
  ]
};