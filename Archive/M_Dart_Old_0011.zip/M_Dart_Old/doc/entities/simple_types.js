GNATdoc.EntitiesCategory = {
  "label": "Simple Types",
  "entities": [
    {
      "label": "Gfx_Byte",
      "docHref": "docs/graphix.html#L11C9",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L11"
    },
    {
      "label": "GfxBuffer",
      "docHref": "docs/graphix.html#L119C9",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L119"
    },
    {
      "label": "HitPoint_Array",
      "docHref": "docs/hitpoints.html#L116C9",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L116"
    },
    {
      "label": "Huge_Integer",
      "docHref": "docs/core_types.html#L35C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L35"
    },
    {
      "label": "Large_Float",
      "docHref": "docs/core_types.html#L62C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L62"
    },
    {
      "label": "Large_Integer",
      "docHref": "docs/core_types.html#L26C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L26"
    },
    {
      "label": "Normal_Float",
      "docHref": "docs/core_types.html#L53C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L53"
    },
    {
      "label": "Normal_Integer",
      "docHref": "docs/core_types.html#L17C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L17"
    },
    {
      "label": "RGB_Value",
      "docHref": "docs/spectra.html#L121C9",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L121"
    },
    {
      "label": "Sample_Array_2D",
      "docHref": "docs/samplers.unitsquares.html#L36C9",
      "declared": "Samplers.UnitSquares",
      "srcHref": "srcs/samplers-unitsquares.ads.html#L36"
    },
    {
      "label": "Small_Float",
      "docHref": "docs/core_types.html#L44C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L44"
    },
    {
      "label": "Small_Integer",
      "docHref": "docs/core_types.html#L8C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L8"
    },
    {
      "label": "Tone_Buffer",
      "docHref": "docs/tone_maps.html#L57C9",
      "declared": "Tone_Maps",
      "srcHref": "srcs/tone_maps.ads.html#L57"
    }
  ]
};