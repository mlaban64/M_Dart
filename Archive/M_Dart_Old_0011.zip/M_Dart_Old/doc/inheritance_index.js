GNATdoc.InheritanceIndex = [
  {
    "label": "Camera",
    "docHref": "docs/cameras.html#L15C9",
    "inherited": [
      {
        "label": "Pinhole_Camera",
        "docHref": "docs/cameras.pinhole_cameras.html#L10C9"
      }
    ]
  },
  {
    "label": "Light",
    "docHref": "docs/lights.html#L18C9",
    "inherited": [
      {
        "label": "Ambient_Light",
        "docHref": "docs/lights.ambient.html#L11C9"
      },
      {
        "label": "Directional_Light",
        "docHref": "docs/lights.directionals.html#L11C9"
      },
      {
        "label": "Point_Light",
        "docHref": "docs/lights.points.html#L11C9"
      }
    ]
  },
  {
    "label": "Material",
    "docHref": "docs/materials.html#L16C9",
    "inherited": [
      {
        "label": "Lambertian",
        "docHref": "docs/materials.lambertians.html#L10C9"
      }
    ]
  },
  {
    "label": "Object",
    "docHref": "docs/objects.html#L23C9",
    "inherited": [
      {
        "label": "Unit_Cone",
        "docHref": "docs/objects.unit_cones.html#L13C9"
      },
      {
        "label": "Unit_Cube",
        "docHref": "docs/objects.unit_cubes.html#L13C9"
      },
      {
        "label": "Unit_Cylinder",
        "docHref": "docs/objects.unit_cylinders.html#L13C9"
      },
      {
        "label": "Unit_Sphere",
        "docHref": "docs/objects.unit_spheres.html#L13C9"
      }
    ]
  },
  {
    "label": "Sampler",
    "docHref": "docs/samplers.html#L15C9",
    "inherited": [
      {
        "label": "UnitSquare_Regular_Sampler",
        "docHref": "docs/samplers.unitsquares.html#L12C9"
      }
    ]
  }
];