#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>
#include "gfxlib.h"

/* Some global variables to hold the X11 objects */
static Display *gfxlib_display = 0x00000000;
static Window gfxlib_window;
static GC gfxlib_gc;
static Colormap gfxlib_colormap;


void gfxlib_openwindow (int width, int height, char *title)
{
  int BLACK, WHITE;
  XSetWindowAttributes attr;
  XEvent e;

  gfxlib_display = XOpenDisplay (0);
  if (!gfxlib_display)
    {
      fprintf (stderr,
	       "GfxLib_OpenWindow: unable to open the graphics window.\n");
      exit (1);
    }

  Visual *visual = DefaultVisual (gfxlib_display, 0);

  if (!(visual && visual->class == TrueColor))
    {
      fprintf (stderr,
	       "GfxLib_OpenWindow: unable to open the graphics window.\n");
      exit (1);
    }

  BLACK = BlackPixel (gfxlib_display, DefaultScreen (gfxlib_display));
  WHITE = WhitePixel (gfxlib_display, DefaultScreen (gfxlib_display));

  gfxlib_window =
    XCreateSimpleWindow (gfxlib_display, DefaultRootWindow (gfxlib_display),
			 0, 0, width, height, 0, BLACK, BLACK);


  attr.backing_store = Always;

  XChangeWindowAttributes (gfxlib_display, gfxlib_window, CWBackingStore,
			   &attr);

  XStoreName (gfxlib_display, gfxlib_window, title);

  XSelectInput (gfxlib_display, gfxlib_window,
		StructureNotifyMask | KeyPressMask | ButtonPressMask);

  XMapWindow (gfxlib_display, gfxlib_window);

  gfxlib_gc = XCreateGC (gfxlib_display, gfxlib_window, 0, 0);

  gfxlib_colormap = DefaultColormap (gfxlib_display, 0);

  XSetForeground (gfxlib_display, gfxlib_gc, WHITE);

  // Wait for the MapNotify event

  while (1)
    {
      XNextEvent (gfxlib_display, &e);
      if (e.type == MapNotify)
	break;
    }
}

void
gfxlib_closewindow ()
{
  XDestroyWindow (gfxlib_display, gfxlib_window);
  XFlush (gfxlib_display);
}

void
gfxlib_setpixel (int x, int y)
{
  XDrawPoint (gfxlib_display, gfxlib_window, gfxlib_gc, x, y);
}

void
gfxlib_setcolor (int r, int g, int b)
{
  static XColor color;

  color.pixel = ((b & 0xff) | ((g & 0xff) << 8) | ((r & 0xff) << 16));
  XSetForeground (gfxlib_display, gfxlib_gc, color.pixel);
}

void
gfxlib_clearwindow ()
{
  XClearWindow (gfxlib_display, gfxlib_window);
}

void
gfxlib_setclearwindow_color (int r, int g, int b)
{
  static XColor color;

  color.pixel = 0;
  color.red = r << 8;
  color.green = g << 8;
  color.blue = b << 8;
  XAllocColor (gfxlib_display, gfxlib_colormap, &color);

  XSetWindowAttributes attr;
  attr.background_pixel = color.pixel;
  XChangeWindowAttributes (gfxlib_display, gfxlib_window, CWBackPixel, &attr);
}

int
gfxlib_checkevent_waiting ()
{
  static XEvent e;

  gfxlib_flushwindow ();

  while (1)
    {
      if (XCheckMaskEvent (gfxlib_display, -1, &e))
	{
	  if (e.type == KeyPress)
	    {
	      XPutBackEvent (gfxlib_display, &e);
	      return 1;
	    }
	  else if (e.type == ButtonPress)
	    {
	      XPutBackEvent (gfxlib_display, &e);
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }
	}
      else
	{
	  return 0;
	}
    }
}

char
gfxlib_waitforevent ()
{
  static XEvent e;

  gfxlib_flushwindow ();

  while (1)
    {
      XNextEvent (gfxlib_display, &e);

      if (e.type == KeyPress)
	{
	  return XLookupKeysym (&e.xkey, 0);
	}
      else if (e.type == ButtonPress)
	{
	  return e.xbutton.button;
	}
    }
}

void
gfxlib_flushwindow ()
{
  XFlush (gfxlib_display);
}
