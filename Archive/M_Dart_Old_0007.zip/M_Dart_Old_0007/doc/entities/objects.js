GNATdoc.EntitiesCategory = {
  "label": "Constants & Variables",
  "entities": [
    {
      "label": "BLACK_RGB_Spec",
      "docHref": "docs/spectra.html#L106C4",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L106"
    },
    {
      "label": "BLUE_FACTOR",
      "docHref": "docs/tone_maps.html#L50C4",
      "declared": "Tone_Maps",
      "srcHref": "srcs/tone_maps.ads.html#L50"
    },
    {
      "label": "BLUE_RGB_Spec",
      "docHref": "docs/spectra.html#L110C4",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L110"
    },
    {
      "label": "CYAN_RGB_Spec",
      "docHref": "docs/spectra.html#L113C4",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L113"
    },
    {
      "label": "Gfx_Main_Image",
      "docHref": "docs/graphix.html#L20C4",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L20"
    },
    {
      "label": "GREEN_FACTOR",
      "docHref": "docs/tone_maps.html#L49C4",
      "declared": "Tone_Maps",
      "srcHref": "srcs/tone_maps.ads.html#L49"
    },
    {
      "label": "GREEN_RGB_Spec",
      "docHref": "docs/spectra.html#L109C4",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L109"
    },
    {
      "label": "Hp_Stack",
      "docHref": "docs/hitpoints.html#L124C4",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L124"
    },
    {
      "label": "M_Dart_Version",
      "docHref": "docs/utilities.html#L8C4",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L8"
    },
    {
      "label": "Main_Tone_Map",
      "docHref": "docs/tone_maps.html#L15C4",
      "declared": "Tone_Maps",
      "srcHref": "srcs/tone_maps.ads.html#L15"
    },
    {
      "label": "MAX_HP_STACK",
      "docHref": "docs/hitpoints.html#L113C4",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L113"
    },
    {
      "label": "MAX_NO_OF_SAMPLES",
      "docHref": "docs/samplers.html#L47C4",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L47"
    },
    {
      "label": "MAX_RECURSION_LEVEL",
      "docHref": "docs/tracers.html#L18C4",
      "declared": "Tracers",
      "srcHref": "srcs/tracers.ads.html#L18"
    },
    {
      "label": "Number_Of_Primary_Rays",
      "docHref": "docs/utilities.html#L22C4",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L22"
    },
    {
      "label": "Number_Of_Unit_Cone_Intersections",
      "docHref": "docs/utilities.html#L25C4",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L25"
    },
    {
      "label": "Number_Of_Unit_Cube_Intersections",
      "docHref": "docs/utilities.html#L26C4",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L26"
    },
    {
      "label": "Number_Of_Unit_Cylinder_Intersections",
      "docHref": "docs/utilities.html#L24C4",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L24"
    },
    {
      "label": "Number_Of_Unit_Sphere_Intersections",
      "docHref": "docs/utilities.html#L23C4",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L23"
    },
    {
      "label": "ORIGIN_3D",
      "docHref": "docs/linear_math.html#L514C4",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L514"
    },
    {
      "label": "PURPLE_RGB_Spec",
      "docHref": "docs/spectra.html#L112C4",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L112"
    },
    {
      "label": "Ray_2PI",
      "docHref": "docs/core_types.html#L75C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L75"
    },
    {
      "label": "Ray_2PI_Inv",
      "docHref": "docs/core_types.html#L77C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L77"
    },
    {
      "label": "Ray_PI",
      "docHref": "docs/core_types.html#L74C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L74"
    },
    {
      "label": "Ray_PI_div2",
      "docHref": "docs/core_types.html#L78C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L78"
    },
    {
      "label": "Ray_PI_div3",
      "docHref": "docs/core_types.html#L79C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L79"
    },
    {
      "label": "Ray_PI_div4",
      "docHref": "docs/core_types.html#L80C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L80"
    },
    {
      "label": "Ray_PI_Inv",
      "docHref": "docs/core_types.html#L76C4",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L76"
    },
    {
      "label": "RED_FACTOR",
      "docHref": "docs/tone_maps.html#L48C4",
      "declared": "Tone_Maps",
      "srcHref": "srcs/tone_maps.ads.html#L48"
    },
    {
      "label": "RED_RGB_Spec",
      "docHref": "docs/spectra.html#L108C4",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L108"
    },
    {
      "label": "The_World",
      "docHref": "docs/scenes.html#L90C4",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L90"
    },
    {
      "label": "WHITE_RGB_Spec",
      "docHref": "docs/spectra.html#L107C4",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L107"
    },
    {
      "label": "X_AXIS_3D",
      "docHref": "docs/linear_math.html#L511C4",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L511"
    },
    {
      "label": "Y_AXIS_3D",
      "docHref": "docs/linear_math.html#L512C4",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L512"
    },
    {
      "label": "YELLOW_RGB_Spec",
      "docHref": "docs/spectra.html#L111C4",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L111"
    },
    {
      "label": "Z_AXIS_3D",
      "docHref": "docs/linear_math.html#L513C4",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L513"
    }
  ]
};