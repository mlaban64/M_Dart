GNATdoc.EntitiesCategory = {
  "label": "Record Types",
  "entities": [
    {
      "label": "Gfx_Image",
      "docHref": "docs/graphix.html#L17C9",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L17"
    },
    {
      "label": "Gfx_Pixel",
      "docHref": "docs/graphix.html#L14C9",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L14"
    },
    {
      "label": "HitPoint",
      "docHref": "docs/hitpoints.html#L17C9",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L17"
    },
    {
      "label": "HitPoint_Stack",
      "docHref": "docs/hitpoints.html#L20C9",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L20"
    },
    {
      "label": "Light_List",
      "docHref": "docs/lights.html#L24C9",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L24"
    },
    {
      "label": "Light_List_Element",
      "docHref": "docs/lights.html#L27C9",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L27"
    },
    {
      "label": "Matrix_3D",
      "docHref": "docs/linear_math.html#L24C9",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L24"
    },
    {
      "label": "Normal_3D",
      "docHref": "docs/linear_math.html#L21C9",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L21"
    },
    {
      "label": "Object_List",
      "docHref": "docs/objects.html#L17C9",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L17"
    },
    {
      "label": "Object_List_Element",
      "docHref": "docs/objects.html#L20C9",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L20"
    },
    {
      "label": "Pinhole_Camera",
      "docHref": "docs/cameras.pinhole_cameras.html#L10C9",
      "declared": "Cameras.Pinhole_Cameras",
      "srcHref": "srcs/cameras-pinhole_cameras.ads.html#L10"
    },
    {
      "label": "Point_2D",
      "docHref": "docs/linear_math.html#L12C9",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L12"
    },
    {
      "label": "Point_3D",
      "docHref": "docs/linear_math.html#L15C9",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L15"
    },
    {
      "label": "Ray",
      "docHref": "docs/linear_math.html#L35C9",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L35"
    },
    {
      "label": "RGB_PixelColor",
      "docHref": "docs/spectra.html#L75C9",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L75"
    },
    {
      "label": "RGB_Spectrum",
      "docHref": "docs/spectra.html#L11C9",
      "declared": "Spectra",
      "srcHref": "srcs/spectra.ads.html#L11"
    },
    {
      "label": "Scene",
      "docHref": "docs/scenes.html#L19C9",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L19"
    },
    {
      "label": "ShadePoint",
      "docHref": "docs/shadepoints.html#L26C9",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L26"
    },
    {
      "label": "ShadePoint_List",
      "docHref": "docs/shadepoints.html#L20C9",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L20"
    },
    {
      "label": "ShadePoint_List_Element",
      "docHref": "docs/shadepoints.html#L23C9",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L23"
    },
    {
      "label": "Tone_Map",
      "docHref": "docs/tone_maps.html#L12C9",
      "declared": "Tone_Maps",
      "srcHref": "srcs/tone_maps.ads.html#L12"
    },
    {
      "label": "Tone_Pixel",
      "docHref": "docs/tone_maps.html#L52C9",
      "declared": "Tone_Maps",
      "srcHref": "srcs/tone_maps.ads.html#L52"
    },
    {
      "label": "Vector_3D",
      "docHref": "docs/linear_math.html#L18C9",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L18"
    }
  ]
};