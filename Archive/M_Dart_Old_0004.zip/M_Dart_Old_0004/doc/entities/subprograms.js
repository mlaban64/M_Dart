GNATdoc.EntitiesCategory = {
  "label": "Subprograms",
  "entities": [
    {
      "label": "*",
      "docHref": "docs/colors.html#L42C14",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L42"
    },
    {
      "label": "*",
      "docHref": "docs/colors.html#L49C14",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L49"
    },
    {
      "label": "*",
      "docHref": "docs/colors.html#L56C14",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L56"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L126C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L126"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L237C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L237"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L244C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L244"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L251C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L251"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L258C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L258"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L360C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L360"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L367C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L367"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L465C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L465"
    },
    {
      "label": "*",
      "docHref": "docs/linear_math.html#L509C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L509"
    },
    {
      "label": "**",
      "docHref": "docs/linear_math.html#L266C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L266"
    },
    {
      "label": "**",
      "docHref": "docs/linear_math.html#L375C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L375"
    },
    {
      "label": "**",
      "docHref": "docs/linear_math.html#L384C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L384"
    },
    {
      "label": "+",
      "docHref": "docs/colors.html#L35C14",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L35"
    },
    {
      "label": "+",
      "docHref": "docs/linear_math.html#L112C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L112"
    },
    {
      "label": "+",
      "docHref": "docs/linear_math.html#L223C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L223"
    },
    {
      "label": "+",
      "docHref": "docs/linear_math.html#L346C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L346"
    },
    {
      "label": "-",
      "docHref": "docs/linear_math.html#L119C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L119"
    },
    {
      "label": "-",
      "docHref": "docs/linear_math.html#L217C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L217"
    },
    {
      "label": "-",
      "docHref": "docs/linear_math.html#L230C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L230"
    },
    {
      "label": "-",
      "docHref": "docs/linear_math.html#L340C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L340"
    },
    {
      "label": "-",
      "docHref": "docs/linear_math.html#L353C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L353"
    },
    {
      "label": "Add_Light",
      "docHref": "docs/lights.html#L44C14",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L44"
    },
    {
      "label": "Add_Object",
      "docHref": "docs/objects.html#L48C14",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L48"
    },
    {
      "label": "Add_ShadePoint",
      "docHref": "docs/shadepoints.html#L64C14",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L64"
    },
    {
      "label": "Closing_Message",
      "docHref": "docs/utilities.html#L13C14",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L13"
    },
    {
      "label": "Construct_Basic_Camera",
      "docHref": "docs/cameras.html#L19C13",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L19"
    },
    {
      "label": "Construct_Normal",
      "docHref": "docs/linear_math.html#L307C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L307"
    },
    {
      "label": "Construct_Pinhole_Camera",
      "docHref": "docs/pinhole_cameras.html#L17C13",
      "declared": "Pinhole_Cameras",
      "srcHref": "srcs/pinhole_cameras.ads.html#L17"
    },
    {
      "label": "Construct_Point",
      "docHref": "docs/linear_math.html#L45C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L45"
    },
    {
      "label": "Construct_Point",
      "docHref": "docs/linear_math.html#L79C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L79"
    },
    {
      "label": "Construct_Ray",
      "docHref": "docs/linear_math.html#L483C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L483"
    },
    {
      "label": "Construct_RGB_Spectrum",
      "docHref": "docs/colors.html#L20C13",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L20"
    },
    {
      "label": "Construct_Rotate_X",
      "docHref": "docs/linear_math.html#L447C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L447"
    },
    {
      "label": "Construct_Rotate_Y",
      "docHref": "docs/linear_math.html#L453C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L453"
    },
    {
      "label": "Construct_Rotate_Z",
      "docHref": "docs/linear_math.html#L459C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L459"
    },
    {
      "label": "Construct_Scale",
      "docHref": "docs/linear_math.html#L428C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L428"
    },
    {
      "label": "Construct_ShadePoint",
      "docHref": "docs/shadepoints.html#L39C13",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L39"
    },
    {
      "label": "Construct_Shear",
      "docHref": "docs/linear_math.html#L436C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L436"
    },
    {
      "label": "Construct_Translation",
      "docHref": "docs/linear_math.html#L420C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L420"
    },
    {
      "label": "Construct_Unit_Cone",
      "docHref": "docs/objects.unit_cones.html#L16C13",
      "declared": "Objects.Unit_Cones",
      "srcHref": "srcs/objects-unit_cones.ads.html#L16"
    },
    {
      "label": "Construct_Unit_Cube",
      "docHref": "docs/objects.unit_cubes.html#L16C13",
      "declared": "Objects.Unit_Cubes",
      "srcHref": "srcs/objects-unit_cubes.ads.html#L16"
    },
    {
      "label": "Construct_Unit_Cylinder",
      "docHref": "docs/objects.unit_cylinders.html#L16C13",
      "declared": "Objects.Unit_Cylinders",
      "srcHref": "srcs/objects-unit_cylinders.ads.html#L16"
    },
    {
      "label": "Construct_Unit_Sphere",
      "docHref": "docs/objects.unit_spheres.html#L16C13",
      "declared": "Objects.Unit_Spheres",
      "srcHref": "srcs/objects-unit_spheres.ads.html#L16"
    },
    {
      "label": "Construct_UnitSquare_Sampler",
      "docHref": "docs/samplers.unitsquares.html#L15C13",
      "declared": "Samplers.UnitSquares",
      "srcHref": "srcs/samplers-unitsquares.ads.html#L15"
    },
    {
      "label": "Construct_Vector",
      "docHref": "docs/linear_math.html#L184C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L184"
    },
    {
      "label": "Convert_RGB_Spectrum",
      "docHref": "docs/colors.html#L91C13",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L91"
    },
    {
      "label": "Core_Type_Facts",
      "docHref": "docs/core_tests.html#L10C14",
      "declared": "Core_Tests",
      "srcHref": "srcs/core_tests.ads.html#L10"
    },
    {
      "label": "Debug_Message",
      "docHref": "docs/utilities.html#L16C14",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L16"
    },
    {
      "label": "Distance",
      "docHref": "docs/linear_math.html#L133C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L133"
    },
    {
      "label": "Distance_Squared",
      "docHref": "docs/linear_math.html#L140C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L140"
    },
    {
      "label": "Distance_To_Org",
      "docHref": "docs/linear_math.html#L147C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L147"
    },
    {
      "label": "Distance_To_Org_Squared",
      "docHref": "docs/linear_math.html#L153C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L153"
    },
    {
      "label": "Free_ShadePoint_List",
      "docHref": "docs/shadepoints.html#L96C14",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L96"
    },
    {
      "label": "Gallery_1_Baseline_Scene1",
      "docHref": "docs/build_functions.html#L7C14",
      "declared": "Build_Functions",
      "srcHref": "srcs/build_functions.ads.html#L7"
    },
    {
      "label": "Gallery_1_Country_House",
      "docHref": "docs/build_functions.html#L9C14",
      "declared": "Build_Functions",
      "srcHref": "srcs/build_functions.ads.html#L9"
    },
    {
      "label": "Gallery_1_Nautilus",
      "docHref": "docs/build_functions.html#L13C14",
      "declared": "Build_Functions",
      "srcHref": "srcs/build_functions.ads.html#L13"
    },
    {
      "label": "Gallery_1_Swirly_Sphere",
      "docHref": "docs/build_functions.html#L11C14",
      "declared": "Build_Functions",
      "srcHref": "srcs/build_functions.ads.html#L11"
    },
    {
      "label": "Generic_Test_World",
      "docHref": "docs/build_functions.html#L19C14",
      "declared": "Build_Functions",
      "srcHref": "srcs/build_functions.ads.html#L19"
    },
    {
      "label": "Get_B",
      "docHref": "docs/colors.html#L86C13",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L86"
    },
    {
      "label": "Get_Background_Color",
      "docHref": "docs/scenes.html#L25C13",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L25"
    },
    {
      "label": "Get_Camera",
      "docHref": "docs/scenes.html#L22C13",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L22"
    },
    {
      "label": "Get_Direction",
      "docHref": "docs/linear_math.html#L503C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L503"
    },
    {
      "label": "Get_FileName",
      "docHref": "docs/scenes.html#L26C13",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L26"
    },
    {
      "label": "Get_First_Light",
      "docHref": "docs/lights.html#L57C13",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L57"
    },
    {
      "label": "Get_First_Object",
      "docHref": "docs/objects.html#L61C13",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L61"
    },
    {
      "label": "Get_First_ShadePoint",
      "docHref": "docs/shadepoints.html#L77C13",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L77"
    },
    {
      "label": "Get_G",
      "docHref": "docs/colors.html#L81C13",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L81"
    },
    {
      "label": "Get_HitPoint",
      "docHref": "docs/shadepoints.html#L52C13",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L52"
    },
    {
      "label": "Get_Lambda",
      "docHref": "docs/hitpoints.html#L47C13",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L47"
    },
    {
      "label": "Get_Light_List",
      "docHref": "docs/scenes.html#L24C13",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L24"
    },
    {
      "label": "Get_Light_Name",
      "docHref": "docs/lights.html#L69C13",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L69"
    },
    {
      "label": "Get_Name",
      "docHref": "docs/scenes.html#L27C13",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L27"
    },
    {
      "label": "Get_Next_Light",
      "docHref": "docs/lights.html#L63C13",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L63"
    },
    {
      "label": "Get_Next_Object",
      "docHref": "docs/objects.html#L67C13",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L67"
    },
    {
      "label": "Get_Next_ShadePoint",
      "docHref": "docs/shadepoints.html#L83C13",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L83"
    },
    {
      "label": "Get_No_Of_Lights",
      "docHref": "docs/lights.html#L51C13",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L51"
    },
    {
      "label": "Get_No_Of_Objects",
      "docHref": "docs/objects.html#L55C13",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L55"
    },
    {
      "label": "Get_No_Of_ShadePoints",
      "docHref": "docs/shadepoints.html#L71C13",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L71"
    },
    {
      "label": "Get_Normal_For_Cube3D",
      "docHref": "docs/objects.unit_cubes.html#L22C13",
      "declared": "Objects.Unit_Cubes",
      "srcHref": "srcs/objects-unit_cubes.ads.html#L22"
    },
    {
      "label": "Get_Object",
      "docHref": "docs/shadepoints.html#L58C13",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L58"
    },
    {
      "label": "Get_Object_List",
      "docHref": "docs/scenes.html#L23C13",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L23"
    },
    {
      "label": "Get_Object_Material",
      "docHref": "docs/objects.html#L86C13",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L86"
    },
    {
      "label": "Get_Object_Name",
      "docHref": "docs/objects.html#L73C13",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L73"
    },
    {
      "label": "Get_Object_Trans",
      "docHref": "docs/objects.html#L99C13",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L99"
    },
    {
      "label": "Get_Object_Trans_Inv",
      "docHref": "docs/objects.html#L105C13",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L105"
    },
    {
      "label": "Get_ObjectHp",
      "docHref": "docs/hitpoints.html#L53C13",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L53"
    },
    {
      "label": "Get_ObjectNv",
      "docHref": "docs/hitpoints.html#L59C13",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L59"
    },
    {
      "label": "Get_Origin",
      "docHref": "docs/linear_math.html#L497C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L497"
    },
    {
      "label": "Get_Pixel_Sampler",
      "docHref": "docs/scenes.html#L71C13",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L71"
    },
    {
      "label": "Get_R",
      "docHref": "docs/colors.html#L76C13",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L76"
    },
    {
      "label": "Get_Single_Ray_For_Pixel",
      "docHref": "docs/pinhole_cameras.html#L35C13",
      "declared": "Pinhole_Cameras",
      "srcHref": "srcs/pinhole_cameras.ads.html#L35"
    },
    {
      "label": "Get_WorldHp",
      "docHref": "docs/hitpoints.html#L65C13",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L65"
    },
    {
      "label": "Get_WorldNv",
      "docHref": "docs/hitpoints.html#L71C13",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L71"
    },
    {
      "label": "Get_X",
      "docHref": "docs/linear_math.html#L59C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L59"
    },
    {
      "label": "Get_X",
      "docHref": "docs/linear_math.html#L94C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L94"
    },
    {
      "label": "Get_X",
      "docHref": "docs/linear_math.html#L199C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L199"
    },
    {
      "label": "Get_X",
      "docHref": "docs/linear_math.html#L322C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L322"
    },
    {
      "label": "Get_Y",
      "docHref": "docs/linear_math.html#L65C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L65"
    },
    {
      "label": "Get_Y",
      "docHref": "docs/linear_math.html#L100C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L100"
    },
    {
      "label": "Get_Y",
      "docHref": "docs/linear_math.html#L205C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L205"
    },
    {
      "label": "Get_Y",
      "docHref": "docs/linear_math.html#L328C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L328"
    },
    {
      "label": "Get_Z",
      "docHref": "docs/linear_math.html#L106C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L106"
    },
    {
      "label": "Get_Z",
      "docHref": "docs/linear_math.html#L211C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L211"
    },
    {
      "label": "Get_Z",
      "docHref": "docs/linear_math.html#L334C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L334"
    },
    {
      "label": "GfxLib_CheckEvent_Waiting",
      "docHref": "docs/graphix.html#L98C13",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L98"
    },
    {
      "label": "GfxLib_ClearWindow",
      "docHref": "docs/graphix.html#L78C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L78"
    },
    {
      "label": "GfxLib_CloseWindow",
      "docHref": "docs/graphix.html#L57C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L57"
    },
    {
      "label": "GfxLib_FlushWindow",
      "docHref": "docs/graphix.html#L93C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L93"
    },
    {
      "label": "GfxLib_OpenWindow",
      "docHref": "docs/graphix.html#L49C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L49"
    },
    {
      "label": "GfxLib_SetClearWindow_Color",
      "docHref": "docs/graphix.html#L84C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L84"
    },
    {
      "label": "GfxLib_SetColor",
      "docHref": "docs/graphix.html#L70C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L70"
    },
    {
      "label": "GfxLib_SetPixel",
      "docHref": "docs/graphix.html#L62C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L62"
    },
    {
      "label": "GfxLib_WaitForEvent",
      "docHref": "docs/graphix.html#L104C13",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L104"
    },
    {
      "label": "Intersect_Objects_With_Ray",
      "docHref": "docs/shadepoints.html#L89C13",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L89"
    },
    {
      "label": "Inverse",
      "docHref": "docs/linear_math.html#L473C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L473"
    },
    {
      "label": "Length",
      "docHref": "docs/linear_math.html#L273C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L273"
    },
    {
      "label": "Length_Squared",
      "docHref": "docs/linear_math.html#L279C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L279"
    },
    {
      "label": "Linear_Math_Ops_Test",
      "docHref": "docs/core_tests.html#L18C14",
      "declared": "Core_Tests",
      "srcHref": "srcs/core_tests.ads.html#L18"
    },
    {
      "label": "Linear_Math_Type_Test",
      "docHref": "docs/core_tests.html#L16C14",
      "declared": "Core_Tests",
      "srcHref": "srcs/core_tests.ads.html#L16"
    },
    {
      "label": "Math_Multiply_Perf_Test",
      "docHref": "docs/core_tests.html#L14C14",
      "declared": "Core_Tests",
      "srcHref": "srcs/core_tests.ads.html#L14"
    },
    {
      "label": "Math_Performance_Test",
      "docHref": "docs/core_tests.html#L12C14",
      "declared": "Core_Tests",
      "srcHref": "srcs/core_tests.ads.html#L12"
    },
    {
      "label": "Normalize",
      "docHref": "docs/linear_math.html#L285C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L285"
    },
    {
      "label": "Normalize",
      "docHref": "docs/linear_math.html#L391C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L391"
    },
    {
      "label": "Objects_Test",
      "docHref": "docs/core_tests.html#L20C14",
      "declared": "Core_Tests",
      "srcHref": "srcs/core_tests.ads.html#L20"
    },
    {
      "label": "Open_Image_Window",
      "docHref": "docs/graphix.html#L22C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L22"
    },
    {
      "label": "Opening_Message",
      "docHref": "docs/utilities.html#L10C14",
      "declared": "Utilities",
      "srcHref": "srcs/utilities.ads.html#L10"
    },
    {
      "label": "Point_On_Ray",
      "docHref": "docs/linear_math.html#L159C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L159"
    },
    {
      "label": "Point_On_Ray",
      "docHref": "docs/linear_math.html#L166C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L166"
    },
    {
      "label": "Pop_HitPoint",
      "docHref": "docs/hitpoints.html#L36C13",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L36"
    },
    {
      "label": "Push_HitPoint",
      "docHref": "docs/hitpoints.html#L26C14",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L26"
    },
    {
      "label": "Put",
      "docHref": "docs/cameras.html#L37C14",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L37"
    },
    {
      "label": "Put",
      "docHref": "docs/colors.html#L28C14",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L28"
    },
    {
      "label": "Put",
      "docHref": "docs/colors.html#L69C14",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L69"
    },
    {
      "label": "Put",
      "docHref": "docs/core_types.html#L11C14",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L11"
    },
    {
      "label": "Put",
      "docHref": "docs/core_types.html#L20C14",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L20"
    },
    {
      "label": "Put",
      "docHref": "docs/core_types.html#L29C14",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L29"
    },
    {
      "label": "Put",
      "docHref": "docs/core_types.html#L38C14",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L38"
    },
    {
      "label": "Put",
      "docHref": "docs/core_types.html#L47C14",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L47"
    },
    {
      "label": "Put",
      "docHref": "docs/core_types.html#L56C14",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L56"
    },
    {
      "label": "Put",
      "docHref": "docs/core_types.html#L65C14",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L65"
    },
    {
      "label": "Put",
      "docHref": "docs/hitpoints.html#L41C14",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L41"
    },
    {
      "label": "Put",
      "docHref": "docs/lights.html#L32C14",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L32"
    },
    {
      "label": "Put",
      "docHref": "docs/lights.html#L38C14",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L38"
    },
    {
      "label": "Put",
      "docHref": "docs/linear_math.html#L52C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L52"
    },
    {
      "label": "Put",
      "docHref": "docs/linear_math.html#L87C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L87"
    },
    {
      "label": "Put",
      "docHref": "docs/linear_math.html#L192C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L192"
    },
    {
      "label": "Put",
      "docHref": "docs/linear_math.html#L315C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L315"
    },
    {
      "label": "Put",
      "docHref": "docs/linear_math.html#L413C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L413"
    },
    {
      "label": "Put",
      "docHref": "docs/linear_math.html#L490C14",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L490"
    },
    {
      "label": "Put",
      "docHref": "docs/materials.html#L25C14",
      "declared": "Materials",
      "srcHref": "srcs/materials.ads.html#L25"
    },
    {
      "label": "Put",
      "docHref": "docs/objects.html#L36C14",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L36"
    },
    {
      "label": "Put",
      "docHref": "docs/objects.html#L42C14",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L42"
    },
    {
      "label": "Put",
      "docHref": "docs/samplers.html#L21C14",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L21"
    },
    {
      "label": "Put",
      "docHref": "docs/shadepoints.html#L46C14",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L46"
    },
    {
      "label": "Render_Scene",
      "docHref": "docs/scenes.html#L76C14",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L76"
    },
    {
      "label": "RGB_Test",
      "docHref": "docs/core_tests.html#L6C14",
      "declared": "Core_Tests",
      "srcHref": "srcs/core_tests.ads.html#L6"
    },
    {
      "label": "Save_Image",
      "docHref": "docs/graphix.html#L30C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L30"
    },
    {
      "label": "Set_Background_Color",
      "docHref": "docs/scenes.html#L47C14",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L47"
    },
    {
      "label": "Set_Camera",
      "docHref": "docs/scenes.html#L29C14",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L29"
    },
    {
      "label": "Set_FileName",
      "docHref": "docs/scenes.html#L53C14",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L53"
    },
    {
      "label": "Set_Light_List",
      "docHref": "docs/scenes.html#L41C14",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L41"
    },
    {
      "label": "Set_Light_Name",
      "docHref": "docs/lights.html#L75C14",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L75"
    },
    {
      "label": "Set_Name",
      "docHref": "docs/scenes.html#L59C14",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L59"
    },
    {
      "label": "Set_Obj_List",
      "docHref": "docs/scenes.html#L35C14",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L35"
    },
    {
      "label": "Set_Object_Material",
      "docHref": "docs/objects.html#L92C14",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L92"
    },
    {
      "label": "Set_Object_Name",
      "docHref": "docs/objects.html#L79C14",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L79"
    },
    {
      "label": "Set_Object_Trans",
      "docHref": "docs/objects.html#L111C14",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L111"
    },
    {
      "label": "Set_Pixel",
      "docHref": "docs/graphix.html#L36C14",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L36"
    },
    {
      "label": "Set_Pixel_Sampler",
      "docHref": "docs/scenes.html#L65C14",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L65"
    },
    {
      "label": "Set_Screen_Params",
      "docHref": "docs/cameras.html#L53C14",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L53"
    },
    {
      "label": "Set_Viewing_Params",
      "docHref": "docs/cameras.html#L44C14",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L44"
    },
    {
      "label": "Sheared_Cubes",
      "docHref": "docs/build_functions.html#L15C14",
      "declared": "Build_Functions",
      "srcHref": "srcs/build_functions.ads.html#L15"
    },
    {
      "label": "Sine_Wave_Pattern",
      "docHref": "docs/core_tests.html#L8C14",
      "declared": "Core_Tests",
      "srcHref": "srcs/core_tests.ads.html#L8"
    },
    {
      "label": "To_Normal_3D",
      "docHref": "docs/linear_math.html#L397C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L397"
    },
    {
      "label": "To_Normal_3D",
      "docHref": "docs/linear_math.html#L403C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L403"
    },
    {
      "label": "To_Point_3D",
      "docHref": "docs/linear_math.html#L174C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L174"
    },
    {
      "label": "To_Vector_3D",
      "docHref": "docs/linear_math.html#L291C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L291"
    },
    {
      "label": "To_Vector_3D",
      "docHref": "docs/linear_math.html#L297C13",
      "declared": "Linear_Math",
      "srcHref": "srcs/linear_math.ads.html#L297"
    },
    {
      "label": "Trace_Ray",
      "docHref": "docs/scenes.html#L81C13",
      "declared": "Scenes",
      "srcHref": "srcs/scenes.ads.html#L81"
    },
    {
      "label": "Unclipped_Spheres",
      "docHref": "docs/build_functions.html#L17C14",
      "declared": "Build_Functions",
      "srcHref": "srcs/build_functions.ads.html#L17"
    }
  ]
};