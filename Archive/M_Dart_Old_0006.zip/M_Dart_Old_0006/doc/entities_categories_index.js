GNATdoc.EntitiesCategoriesIndex = [
  {
    "label": "Constants & Variables",
    "href": "entities/objects.html"
  },
  {
    "label": "Simple Types",
    "href": "entities/simple_types.html"
  },
  {
    "label": "Access Types",
    "href": "entities/access_types.html"
  },
  {
    "label": "Record Types",
    "href": "entities/record_types.html"
  },
  {
    "label": "Tagged Types",
    "href": "entities/tagged_types.html"
  },
  {
    "label": "Subprograms",
    "href": "entities/subprograms.html"
  },
  {
    "label": "Packages",
    "href": "entities/packages.html"
  }
];