GNATdoc.EntitiesCategory = {
  "label": "Simple Types",
  "entities": [
    {
      "label": "Gfx_Byte",
      "docHref": "docs/graphix.html#L11C9",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L11"
    },
    {
      "label": "GfxBuffer",
      "docHref": "docs/graphix.html#L118C9",
      "declared": "GraphiX",
      "srcHref": "srcs/graphix.ads.html#L118"
    },
    {
      "label": "HitPoint_Array",
      "docHref": "docs/hitpoints.html#L95C9",
      "declared": "HitPoints",
      "srcHref": "srcs/hitpoints.ads.html#L95"
    },
    {
      "label": "Huge_Integer",
      "docHref": "docs/core_types.html#L35C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L35"
    },
    {
      "label": "Large_Float",
      "docHref": "docs/core_types.html#L62C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L62"
    },
    {
      "label": "Large_Integer",
      "docHref": "docs/core_types.html#L26C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L26"
    },
    {
      "label": "Normal_Float",
      "docHref": "docs/core_types.html#L53C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L53"
    },
    {
      "label": "Normal_Integer",
      "docHref": "docs/core_types.html#L17C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L17"
    },
    {
      "label": "RGB_Value",
      "docHref": "docs/colors.html#L116C9",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L116"
    },
    {
      "label": "Sample_Array",
      "docHref": "docs/samplers.unitsquares.html#L36C9",
      "declared": "Samplers.UnitSquares",
      "srcHref": "srcs/samplers-unitsquares.ads.html#L36"
    },
    {
      "label": "Small_Float",
      "docHref": "docs/core_types.html#L44C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L44"
    },
    {
      "label": "Small_Integer",
      "docHref": "docs/core_types.html#L8C9",
      "declared": "Core_Types",
      "srcHref": "srcs/core_types.ads.html#L8"
    },
    {
      "label": "Spectrum",
      "docHref": "docs/colors.html#L11C9",
      "declared": "Colors",
      "srcHref": "srcs/colors.ads.html#L11"
    }
  ]
};