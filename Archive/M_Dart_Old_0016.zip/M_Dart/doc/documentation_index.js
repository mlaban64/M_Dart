GNATdoc.DocumentationIndex = [
  {
    "label": "Cameras\n",
    "items": [
      {
        "label": "Cameras",
        "file": "docs/cameras.html"
      },
      {
        "label": "Cameras.Pinhole_Cameras",
        "file": "docs/cameras.pinhole_cameras.html"
      }
    ]
  },
  {
    "label": "Core\n",
    "items": [
      {
        "label": "Core_Types",
        "file": "docs/core_types.html"
      },
      {
        "label": "Linear_Math",
        "file": "docs/linear_math.html"
      }
    ]
  },
  {
    "label": "Materials\n",
    "items": [
      {
        "label": "Materials",
        "file": "docs/materials.html"
      },
      {
        "label": "Materials.Lambertians",
        "file": "docs/materials.lambertians.html"
      },
      {
        "label": "Materials.Reflective",
        "file": "docs/materials.reflective.html"
      }
    ]
  },
  {
    "label": "Objects\n",
    "items": [
      {
        "label": "HitPoints",
        "file": "docs/hitpoints.html"
      },
      {
        "label": "Objects",
        "file": "docs/objects.html"
      },
      {
        "label": "Objects.Unit_Cones",
        "file": "docs/objects.unit_cones.html"
      },
      {
        "label": "Objects.Unit_Cubes",
        "file": "docs/objects.unit_cubes.html"
      },
      {
        "label": "Objects.Unit_Cylinders",
        "file": "docs/objects.unit_cylinders.html"
      },
      {
        "label": "Objects.Unit_Spheres",
        "file": "docs/objects.unit_spheres.html"
      }
    ]
  },
  {
    "label": "Rendering\n",
    "items": [
      {
        "label": "Scenes",
        "file": "docs/scenes.html"
      },
      {
        "label": "ShadePoints",
        "file": "docs/shadepoints.html"
      },
      {
        "label": "Spectra",
        "file": "docs/spectra.html"
      },
      {
        "label": "Tracers",
        "file": "docs/tracers.html"
      }
    ]
  },
  {
    "label": "Utilities\n",
    "items": [
      {
        "label": "Core_Tests",
        "file": "docs/core_tests.html"
      },
      {
        "label": "GraphiX",
        "file": "docs/graphix.html"
      },
      {
        "label": "Tone_Maps",
        "file": "docs/tone_maps.html"
      },
      {
        "label": "Utilities",
        "file": "docs/utilities.html"
      }
    ]
  },
  {
    "label": "Lights",
    "file": "docs/lights.html"
  },
  {
    "label": "Lights.Ambient",
    "file": "docs/lights.ambient.html"
  },
  {
    "label": "Lights.Directionals",
    "file": "docs/lights.directionals.html"
  },
  {
    "label": "Lights.Points",
    "file": "docs/lights.points.html"
  },
  {
    "label": "Samplers",
    "file": "docs/samplers.html"
  },
  {
    "label": "Samplers.UnitSquares",
    "file": "docs/samplers.unitsquares.html"
  }
];