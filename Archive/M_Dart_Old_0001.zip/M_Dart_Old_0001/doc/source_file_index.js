GNATdoc.SourceFileIndex = [
  {
    "label": "build_functions.ads",
    "srcHref": "srcs/build_functions.ads.html"
  },
  {
    "label": "cameras.ads",
    "srcHref": "srcs/cameras.ads.html"
  },
  {
    "label": "colors.ads",
    "srcHref": "srcs/colors.ads.html"
  },
  {
    "label": "core_tests.ads",
    "srcHref": "srcs/core_tests.ads.html"
  },
  {
    "label": "core_types.ads",
    "srcHref": "srcs/core_types.ads.html"
  },
  {
    "label": "gnattest_generated.ads",
    "srcHref": "srcs/gnattest_generated.ads.html"
  },
  {
    "label": "graphix.ads",
    "srcHref": "srcs/graphix.ads.html"
  },
  {
    "label": "hitpoints.ads",
    "srcHref": "srcs/hitpoints.ads.html"
  },
  {
    "label": "large_float_functions.ads",
    "srcHref": "srcs/large_float_functions.ads.html"
  },
  {
    "label": "lights-directionals.ads",
    "srcHref": "srcs/lights-directionals.ads.html"
  },
  {
    "label": "lights.ads",
    "srcHref": "srcs/lights.ads.html"
  },
  {
    "label": "linear_math.ads",
    "srcHref": "srcs/linear_math.ads.html"
  },
  {
    "label": "materials-lambertians.ads",
    "srcHref": "srcs/materials-lambertians.ads.html"
  },
  {
    "label": "materials.ads",
    "srcHref": "srcs/materials.ads.html"
  },
  {
    "label": "normal_float_functions.ads",
    "srcHref": "srcs/normal_float_functions.ads.html"
  },
  {
    "label": "objects-unit_cones.ads",
    "srcHref": "srcs/objects-unit_cones.ads.html"
  },
  {
    "label": "objects-unit_cubes.ads",
    "srcHref": "srcs/objects-unit_cubes.ads.html"
  },
  {
    "label": "objects-unit_cylinders.ads",
    "srcHref": "srcs/objects-unit_cylinders.ads.html"
  },
  {
    "label": "objects-unit_spheres.ads",
    "srcHref": "srcs/objects-unit_spheres.ads.html"
  },
  {
    "label": "objects.ads",
    "srcHref": "srcs/objects.ads.html"
  },
  {
    "label": "pinhole_cameras.ads",
    "srcHref": "srcs/pinhole_cameras.ads.html"
  },
  {
    "label": "samplers-unitsquares.ads",
    "srcHref": "srcs/samplers-unitsquares.ads.html"
  },
  {
    "label": "samplers.ads",
    "srcHref": "srcs/samplers.ads.html"
  },
  {
    "label": "scenes.ads",
    "srcHref": "srcs/scenes.ads.html"
  },
  {
    "label": "shadepoints.ads",
    "srcHref": "srcs/shadepoints.ads.html"
  },
  {
    "label": "small_float_functions.ads",
    "srcHref": "srcs/small_float_functions.ads.html"
  },
  {
    "label": "utilities.ads",
    "srcHref": "srcs/utilities.ads.html"
  }
];