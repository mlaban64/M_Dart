GNATdoc.Documentation = {
  "label": "Gnattest_Generated.GNATtest_Standard",
  "summary": [
  ],
  "description": [
  ],
  "entities": [
  ]
};