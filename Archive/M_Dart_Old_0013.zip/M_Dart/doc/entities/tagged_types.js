GNATdoc.EntitiesCategory = {
  "label": "Tagged Types",
  "entities": [
    {
      "label": "Ambient_Light",
      "docHref": "docs/lights.ambient.html#L11C9",
      "declared": "Lights.Ambient",
      "srcHref": "srcs/lights-ambient.ads.html#L11"
    },
    {
      "label": "Box_Filter",
      "docHref": "docs/cameras.html#L130C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L130"
    },
    {
      "label": "Camera",
      "docHref": "docs/cameras.html#L16C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L16"
    },
    {
      "label": "Directional_Light",
      "docHref": "docs/lights.directionals.html#L11C9",
      "declared": "Lights.Directionals",
      "srcHref": "srcs/lights-directionals.ads.html#L11"
    },
    {
      "label": "Filter",
      "docHref": "docs/cameras.html#L124C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L124"
    },
    {
      "label": "Lambertian",
      "docHref": "docs/materials.lambertians.html#L9C9",
      "declared": "Materials.Lambertians",
      "srcHref": "srcs/materials-lambertians.ads.html#L9"
    },
    {
      "label": "Light",
      "docHref": "docs/lights.html#L18C9",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L18"
    },
    {
      "label": "Material",
      "docHref": "docs/materials.html#L16C9",
      "declared": "Materials",
      "srcHref": "srcs/materials.ads.html#L16"
    },
    {
      "label": "MultiStage_Filter",
      "docHref": "docs/cameras.html#L133C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L133"
    },
    {
      "label": "Object",
      "docHref": "docs/objects.html#L23C9",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L23"
    },
    {
      "label": "Point_Light",
      "docHref": "docs/lights.points.html#L11C9",
      "declared": "Lights.Points",
      "srcHref": "srcs/lights-points.ads.html#L11"
    },
    {
      "label": "Poisson_Filter",
      "docHref": "docs/cameras.html#L136C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L136"
    },
    {
      "label": "Reflective",
      "docHref": "docs/materials.reflective.html#L12C9",
      "declared": "Materials.Reflective",
      "srcHref": "srcs/materials-reflective.ads.html#L12"
    },
    {
      "label": "Sampler",
      "docHref": "docs/samplers.html#L18C9",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L18"
    },
    {
      "label": "Sampler_2D",
      "docHref": "docs/samplers.html#L83C9",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L83"
    },
    {
      "label": "Sampler_3D",
      "docHref": "docs/samplers.html#L88C9",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L88"
    },
    {
      "label": "Unit_Cone",
      "docHref": "docs/objects.unit_cones.html#L13C9",
      "declared": "Objects.Unit_Cones",
      "srcHref": "srcs/objects-unit_cones.ads.html#L13"
    },
    {
      "label": "Unit_Cube",
      "docHref": "docs/objects.unit_cubes.html#L13C9",
      "declared": "Objects.Unit_Cubes",
      "srcHref": "srcs/objects-unit_cubes.ads.html#L13"
    },
    {
      "label": "Unit_Cylinder",
      "docHref": "docs/objects.unit_cylinders.html#L13C9",
      "declared": "Objects.Unit_Cylinders",
      "srcHref": "srcs/objects-unit_cylinders.ads.html#L13"
    },
    {
      "label": "Unit_Sphere",
      "docHref": "docs/objects.unit_spheres.html#L13C9",
      "declared": "Objects.Unit_Spheres",
      "srcHref": "srcs/objects-unit_spheres.ads.html#L13"
    },
    {
      "label": "UnitSquare_Random_Sampler",
      "docHref": "docs/samplers.unitsquares.html#L18C9",
      "declared": "Samplers.UnitSquares",
      "srcHref": "srcs/samplers-unitsquares.ads.html#L18"
    },
    {
      "label": "UnitSquare_Regular_Sampler",
      "docHref": "docs/samplers.unitsquares.html#L15C9",
      "declared": "Samplers.UnitSquares",
      "srcHref": "srcs/samplers-unitsquares.ads.html#L15"
    }
  ]
};