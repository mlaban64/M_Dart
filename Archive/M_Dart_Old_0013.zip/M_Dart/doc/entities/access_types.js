GNATdoc.EntitiesCategory = {
  "label": "Access Types",
  "entities": [
    {
      "label": "Ambient_Light_Ptr",
      "docHref": "docs/lights.ambient.html#L14C9",
      "declared": "Lights.Ambient",
      "srcHref": "srcs/lights-ambient.ads.html#L14"
    },
    {
      "label": "Camera_Ptr",
      "docHref": "docs/cameras.html#L19C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L19"
    },
    {
      "label": "Directional_Light_Ptr",
      "docHref": "docs/lights.directionals.html#L14C9",
      "declared": "Lights.Directionals",
      "srcHref": "srcs/lights-directionals.ads.html#L14"
    },
    {
      "label": "Filter_Ptr",
      "docHref": "docs/cameras.html#L127C9",
      "declared": "Cameras",
      "srcHref": "srcs/cameras.ads.html#L127"
    },
    {
      "label": "Lambertian_Ptr",
      "docHref": "docs/materials.lambertians.html#L11C9",
      "declared": "Materials.Lambertians",
      "srcHref": "srcs/materials-lambertians.ads.html#L11"
    },
    {
      "label": "Light_List_Element_Ptr",
      "docHref": "docs/lights.html#L30C9",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L30"
    },
    {
      "label": "Light_Ptr",
      "docHref": "docs/lights.html#L21C9",
      "declared": "Lights",
      "srcHref": "srcs/lights.ads.html#L21"
    },
    {
      "label": "Material_Ptr",
      "docHref": "docs/materials.html#L19C9",
      "declared": "Materials",
      "srcHref": "srcs/materials.ads.html#L19"
    },
    {
      "label": "Object_List_Element_Ptr",
      "docHref": "docs/objects.html#L29C9",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L29"
    },
    {
      "label": "Object_Ptr",
      "docHref": "docs/objects.html#L26C9",
      "declared": "Objects",
      "srcHref": "srcs/objects.ads.html#L26"
    },
    {
      "label": "Point_Light_Ptr",
      "docHref": "docs/lights.points.html#L14C9",
      "declared": "Lights.Points",
      "srcHref": "srcs/lights-points.ads.html#L14"
    },
    {
      "label": "Reflective_Ptr",
      "docHref": "docs/materials.reflective.html#L14C9",
      "declared": "Materials.Reflective",
      "srcHref": "srcs/materials-reflective.ads.html#L14"
    },
    {
      "label": "Sampler_Ptr",
      "docHref": "docs/samplers.html#L21C9",
      "declared": "Samplers",
      "srcHref": "srcs/samplers.ads.html#L21"
    },
    {
      "label": "ShadePoint_List_Element_Ptr",
      "docHref": "docs/shadepoints.html#L32C9",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L32"
    },
    {
      "label": "ShadePoint_Ptr",
      "docHref": "docs/shadepoints.html#L29C9",
      "declared": "ShadePoints",
      "srcHref": "srcs/shadepoints.ads.html#L29"
    }
  ]
};